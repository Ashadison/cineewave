// Future dynamic features (search, filtering, etc.)
document.addEventListener("DOMContentLoaded", () => {
  console.log("CineWave loaded ✅");
});